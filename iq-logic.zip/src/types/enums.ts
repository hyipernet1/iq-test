export enum TOKEN {
    ACCESS_TOKEN = "accessToken",
    REFRESH_TOKEN = "refreshToken",
}

export enum TIER {
    BASIC = "BASIC",
    MONTH = "MONTH",
}